# CHUNK STREAMING & PERSISTENCE ARCHITECTURE
**Project:** THE VIVARIUM  
**Branch:** `task/021-world-integration`  
**Classification:** Architecture Specification / Non-Runtime Document  
**Status:** DESIGN APPROVED (Game Director Review Aligned) / IMPLEMENTATION HOLD  
**Author:** Antigravity (World Architecture Division — Branch 04)  
**Date:** 2026-11-11  

---

## 1. SCOPE & OBJECTIVE

Tài liệu này xác định kiến trúc quản lý, nạp/xả động (Streaming), đồng bộ biên giới và lưu trữ bền vững (Persistence) cho các khối thế giới (**Chunks**) trong *THE VIVARIUM*. 

Mục tiêu cốt lõi: Cho phép thế giới mở rộng quy mô lớn trên nền tảng Web browser mà không gây tràn bộ nhớ (Out-Of-Memory - OOM) hay tụt khung hình (Frame Drop), đồng thời đảm bảo mọi tương tác đào, lấp, xây dựng của người chơi được lưu trữ xác định và nhất quán tuyệt đối.

---

## 2. QUY CHUẨN KÍCH THƯỚC CHUNK & TỌA ĐỘ THẾ GIỚI 2D

### 2.1 Kích Thước Tiêu Chuẩn (Grid Standards)
- **Kích thước một ô (Cell/Tile):** $16 \times 16$ pixels (hoặc tỉ lệ tương đương theo render engine).
- **Kích thước Chunk:** $64 \times 64$ cells.
- **Quy mô hiển thị 1 Chunk:** $1024 \times 1024$ world units.
- **Cấu hình Prototype V1 (TASK-021 Verification):** Lưới **$2 \times 3$ Chunks** (2 cột ngang $X \in [0, 1]$, 3 tầng sâu $Y \in [0, 2]$) = Tổng cộng 6 Chunks ($128 \times 192$ cells).

```
   Chunk (0, 0) [Bề mặt: Ancient Forest]   |   Chunk (1, 0) [Bề mặt: Breeze Meadow]
   ----------------------------------------+---------------------------------------
   Chunk (0, 1) [Tầng đất mùn & Rễ sâu]    |   Chunk (1, 1) [Tầng sét & Mạch nước nông]
   ----------------------------------------+---------------------------------------
   Chunk (0, 2) [Hang đá vôi Karst ngầm]   |   Chunk (1, 2) [Tầng đá nứt & Đáy hang]
```

### 2.2 Hệ Thống Tọa Độ Xác Định (Coordinate System)
- **Global Cell Coordinates $(x, y)$:**
  - $x \in \mathbb{Z}$: Tọa độ ô toàn cục theo phương ngang.
  - $y \in \mathbb{Z}$: Tọa độ ô toàn cục theo chiều sâu ($y = 0$ là mặt đất cơ sở, $y > 0$ là lòng đất).
- **Chunk Coordinates $(cx, cy)$:**
  $$cx = \lfloor x / 64 \rfloor, \quad cy = \lfloor y / 64 \rfloor$$
- **Local Cell Coordinates $(lx, ly)$ trong Chunk:**
  $$lx = ((x \pmod{64}) + 64) \pmod{64}, \quad ly = ((y \pmod{64}) + 64) \pmod{64}$$

---

## 3. DETERMINISTIC GENERATION & TÁCH BIỆT DELTA STATE

Để tối ưu hóa dung lượng lưu trữ (Save State) từ hàng trăm Megabyte xuống chỉ còn vài Kilobyte, kiến trúc áp dụng mô hình **Dual-Layer Chunk State**:

```
+------------------------------------------------------------------------+
| 1. DETERMINISTIC BASE LAYER (Không lưu vào Save File)                  |
| Sinh tự động từ: WorldSeed + (GlobalX, GlobalY) qua Perlin/Simplex     |
| Kết quả luôn đồng nhất 100% trên mọi máy client.                       |
+------------------------------------------------------------------------+
                                  +
+------------------------------------------------------------------------+
| 2. PLAYER MODIFICATION DELTA LAYER (Được lưu bền vững)                 |
| Chỉ lưu các ô bị người chơi tác động:                                  |
| - Ô bị đào rỗng (Dug cell)                                             |
| - Ô được đắp bùn sét (Filled cell)                                     |
| - Nhánh rễ bị cắt đứt                                                  |
| - Công trình / kho chứa tổ kiến xây thêm                               |
+------------------------------------------------------------------------+
                                  =
+------------------------------------------------------------------------+
| FINAL RUNTIME CELL STATE (Trạng thái hiển thị và vật lý thực tế)      |
+------------------------------------------------------------------------+
```

---

## 4. CHUNK LIFECYCLE & STREAMING PIPELINE

Kiến trúc quản lý vòng đời Chunk được điều phối bởi `ChunkLifecycleManager` dựa trên khoảng cách đến Camera Viewport:

```mermaid
flowchart LR
    Unloaded -->|Player approaches| Generating[1. Generating Base Seed]
    Generating -->|Apply Delta| Active[2. Active Simulation & Render]
    Active -->|Player moves away| Dormant[3. Dormant / Cached in RAM]
    Dormant -->|Cache eviction| Serializing[4. Serialize Deltas to IndexedDB]
    Serializing --> Unloaded
```

1. **Active Window:** Chunks nằm trong tầm nhìn camera $+ 1$ chunk đệm xung quanh (khoảng $3 \times 4$ Chunks tối đa được render và tick vật lý).
2. **Dormant Window:** Chunks vừa ra khỏi tầm nhìn được giữ trong LRU Cache (bộ nhớ tạm RAM) tối đa 16 Chunks để nếu người chơi quay lại thì không cần nạp lại từ đĩa.
3. **Eviction & Serialization:** Khi bộ nhớ RAM chạm ngưỡng cảnh báo, Chunks xa nhất sẽ trích xuất Delta Layer, nén và ghi xuống `IndexedDB` / `LocalStorage`, giải phóng hoàn toàn bộ nhớ PixiJS textures và mesh.

---

## 5. ĐỒNG BỘ LIÊN BIÊN GIỚI CHUNK (CROSS-CHUNK CONSISTENCY)

Để ngăn ngừa lỗi rạn nứt địa hình (Edge Seams), đứt dòng nước hoặc gián đoạn đường đi của kiến tại đường biên giữa hai Chunk:

1. **Hàm Sinh Địa Hình Toàn Cục (Global Domain Noise):**
   - Mọi hàm tạo nhiễu Perlin/Simplex đều nhận tham số là tọa độ toàn cục $(GlobalX, GlobalY)$, tuyệt đối không nhận tọa độ cục bộ $(lx, ly)$. Nhờ đó, giá trị bề mặt tại $lx = 63$ của Chunk 0 và $lx = 0$ của Chunk 1 luôn khớp trơn tru.
2. **Túi Nước & Thủy Văn Biên Giới (Cross-Chunk Fluid Balance):**
   - Khi nước chảy chạm biên Chunk $lx = 63$, sự kiện truyền thể tích nước được gửi vào hàng đợi thông điệp biên (**Cross-Chunk Boundary Queue**). Nếu Chunk lân cận đang ở trạng thái Unloaded, dữ liệu nước được ghi trực tiếp vào Delta Layer của Chunk lân cận để áp dụng ngay khi Chunk đó được nạp.
3. **Pathfinding Across Chunks:**
   - Đồ thị di chuyển (Navigation Graph) của đàn kiến sử dụng cấu trúc phân tầng (Hierarchical Pathfinding - HPA*), lưu các cổng biên giới (Boundary Portals) tại mép các Chunk để tìm đường xuyên biên mà không cần nạp toàn bộ các Chunk trung gian vào bộ nhớ.

---

## 6. DESIGN-ONLY DATA CONTRACTS (TYPESCRIPT)

```typescript
export interface CellDeltaRecord {
  readonly localIndex: number; // lx + ly * 64 (0..4095)
  readonly modifiedType: 'AIR_DUG' | 'CLAY_FILLED' | 'ROOT_SEVERED' | 'WATER_POCKET';
  readonly moistureLevel?: number;
  readonly metadata?: string;
}

export interface ChunkDeltaState {
  readonly chunkX: number;
  readonly chunkY: number;
  readonly timestamp: number;
  readonly deltas: CellDeltaRecord[];
}

export interface ChunkPersistenceManifest {
  readonly worldSeed: number;
  readonly worldVersion: string;
  readonly modifiedChunkKeys: string[]; // "cx,cy"
}
```

---

## 7. ACCEPTANCE CRITERIA
- [x] Quy chuẩn kích thước Chunk chuẩn $64 \times 64$, tương thích Prototype V1 quy mô 6 Chunks ($2 \times 3$).
- [x] Thiết lập nguyên lý Deterministic Generation tách rời Base Layer và Delta Layer.
- [x] Giải quyết triệt để bài toán đồng bộ liên biên giới Chunk (Seam cracking, Cross-chunk fluid).
- [x] Đạt ngân sách bộ nhớ Web: LRU Cache kiểm soát chặt chẽ, tuần tự hóa lưu trữ IndexedDB không giật lag.
