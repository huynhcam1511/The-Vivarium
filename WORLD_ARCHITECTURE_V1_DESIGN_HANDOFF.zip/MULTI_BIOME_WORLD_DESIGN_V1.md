# MULTI-BIOME WORLD DESIGN V1
**Project:** THE VIVARIUM  
**Branch:** `task/021-world-integration`  
**Classification:** Architecture Specification / Non-Runtime Document  
**Status:** DESIGN APPROVED (Game Director Review Aligned) / IMPLEMENTATION HOLD  
**Author:** Antigravity (World Architecture Division — Branch 04)  
**Date:** 2026-11-11  

---

## 1. SCOPE & VISION

### 1.1 Mục Tiêu Thiết Kế
Tài liệu này xác lập nền tảng kiến trúc thế giới đa hệ sinh thái (**Multi-Layer Ecological World Architecture**) cho *THE VIVARIUM*. Thiết kế khắc phục hoàn toàn hạn chế của mô hình đơn sinh cảnh tĩnh (chỉ có một cây sồi và một hồ nước phẳng), hướng tới một thế giới mở rộng theo chiều ngang và liên kết sâu theo chiều dọc.

### 1.2 Triết Lý Module Kiểu Lego (Data-Driven Architecture)
- **Tách biệt dữ liệu và mã nguồn:** Mọi Biome được mô tả bằng dữ liệu (Data Contracts / JSON schema / TypeScript interfaces), không mã hóa cứng (hardcode) trong vòng lặp game hay render engine.
- **Khả năng mở rộng độc lập:** Thêm mới một Biome (ví dụ Biome 09, 10) trong tương lai chỉ cần định nghĩa thêm Data Profile mà không làm xáo trộn World Engine cốt lõi.
- **Không gian tọa độ 2D thống nhất:** Hệ tọa độ thực thi duy nhất là 2D Cartesisan `(X, Y)`:
  - Trục `X`: Chiều ngang thế giới (Surface distance).
  - Trục `Y`: Chiều sâu địa chất (`Y = 0` là mực chuẩn bề mặt, `Y > 0` là độ sâu lòng đất).

---

## 2. PHÂN ĐỊNH BA KHÔNG GIAN ĐỊA LÝ & SINH THÁI

Nhằm ngăn ngừa sự nhầm lẫn giữa cảnh quan mặt đất, hệ thống hang ngầm và tầng địa chất vật lý, kiến trúc phân định rõ 3 khái niệm:

```
+-------------------------------------------------------------------------+
| SURFACE BIOMES (6)                                                      |
| Ancient Forest | Breeze Meadow | Wetland | Dunes | Canyon | Cold Forest |
+-------------------------------------------------------------------------+
| GEOLOGICAL STRATIFICATION (Tầng địa chất biến thiên liên tục theo Y)     |
| [Tầng 1: Đất mùn / Topsoil]                                            |
| [Tầng 2: Đất nén & Bùn sét / Subsoil]                                   |
| [Tầng 3: Đá phong hóa & Khe nứt / Fractured Strata]                     |
| [Tầng 4: Đá gốc & Nền móng / Bedrock]                                   |
+-------------------------------------------------------------------------+
| SUBTERRANEAN BIOMES (2)                                                 |
| Limestone Caverns (Karst Hydrology) | Crystal Depths (Fantasy / Optional)|
+-------------------------------------------------------------------------+
```

1. **Surface Biomes (Sinh cảnh bề mặt):** Chịu chi phối trực tiếp của thời tiết, nắng, gió và lượng mưa trên không.
2. **Geological Layers (Tầng địa chất):** Quy luật phân tầng vật lý của đất đá theo độ sâu $Y$, áp dụng thống nhất nhưng có độ dày và độ xốp biến thiên theo từng Biome bề mặt.
3. **Subterranean Biomes (Sinh thái ngầm đặc thù):** Các khoang rỗng, mạng lưới hang karst hoặc vùng địa nhiệt/tinh thể sâu có vi khí hậu và chu trình sinh thái khép kín.

---

## 3. DANH MỤC 8 BIOMES CHÍNH THỨC (PHÂN LOẠI & LỘ TRÌNH)

### 3.1 Nhóm 6 Surface Biomes
1. **01 — Ancient Forest (Rừng cổ thụ):**
   - *Đặc điểm:* Rừng đại thụ râm mát, độ ẩm cao. Tập trung vào hệ rễ khổng lồ, mạng lưới nấm hoại sinh phân hủy gỗ mục và chu trình mùn hữu cơ. Nấm phát quang là loài đặc hữu hiếm ở hốc tối chân rễ.
2. **02 — Breeze Meadow (Đồng cỏ gió):**
   - *Đặc điểm:* Đồng cỏ thoai thoải, độ ẩm vừa, gió mặt đất liên tục. Đất mềm dễ đào, phát tán hạt giống hoa dại, thích hợp làm sinh thái khởi đầu (Spawn zone).
3. **03 — Wetland & Marsh (Đầm lầy & Vùng ngập nước):**
   - *Đặc điểm:* Bùn sét lầy lội, nước ngầm bão hòa, nguy cơ ngập úng cao. Là nguồn cung bùn sét (Clay/Mud) phục vụ đắp tổ và trữ ẩm.
4. **04 — Coastal Dunes (Cồn cát ven biển):**
   - *Đặc điểm:* Cát xốp hạt mịn, bốc hơi mạnh, gió thổi tạo đụn. Địa chất dễ sạt lở khi đào hầm không có trụ chống. Chứa thấu kính nước ngọt (Freshwater Lens) nằm trên tầng nước mặn; nguy cơ xâm nhập mặn khi khai thác cạn kiệt.
5. **05 — Arid Canyon (Hẻm núi khô cằn):**
   - *Đặc điểm:* Biên độ nhiệt ngày/đêm lớn, vách đá phiến và khe nứt. Kiến khai thác bằng cơ học tự nhiên: cạy vụn đất xốp trong khe nứt đá, không sử dụng công cụ đục khoáng kiểu con người.
6. **06 — Cold Forest (Rừng tuyết lạnh):**
   - *Đặc điểm:* Lạnh giá, tuyết phủ theo mùa. Phân biệt rõ hai tầng băng: Lớp đất đóng băng theo mùa (*Seasonal Frost Layer*) và tầng băng vĩnh cửu sâu (*Permafrost*). Hiện tượng rã đông làm nền đất yếu và gây sụt lún cơ học.

### 3.2 Nhóm 2 Subterranean Biomes
7. **07 — Limestone Caverns (Hang karst đá vôi):**
   - *Đặc điểm:* Hệ thống hang động ngầm liên thông, suối ngầm dòng chảy nhanh qua các ống dẫn karst xói mòn tự nhiên, nhũ đá, độ ẩm 100%. Nước và cặn bẩn di chuyển nhanh dọc các kênh karst.
8. **08 — Crystal Depths (Vực tinh thể sâu — Fantasy / Optional):**
   - *Phân loại:* **Nội dung Giả tưởng / Tùy chọn (Optional Expansion)**.
   - *Đặc điểm:* Vùng tinh thể khoáng sản sâu, phát quang tự nhiên nhờ phản ứng khoáng vật hoặc địa nhiệt. Tuyệt đối **không** áp đặt bức xạ hạt nhân hay năng lượng giả tưởng làm quy luật sinh thái mặc định của Vivarium.

---

## 4. LỘ TRÌNH TRIỂN KHAI THEO GIAI ĐOẠN (STAGED ROADMAP)

| Giai đoạn | Mục tiêu Biome | Quy mô & Phạm vi kiểm chứng |
| :--- | :--- | :--- |
| **V1 — Core (TASK-021 Verification)** | **Ancient Forest**, **Breeze Meadow**, **Wetland & Marsh**, **Limestone Caverns** | Kiểm chứng trên lưới **2×3 Chunks** (Prototype 6 Chunks, $64 \times 64$ cells/chunk). Xác thực chuyển tiếp rừng–cỏ, bùn sét, nước thấm và hệ hang ngầm karst. |
| **V2 — Expansion** | **Coastal Dunes**, **Arid Canyon** | Kiểm chứng cơ chế sạt lở cát, thấu kính nước ngọt và cơ học đào khe nứt đá vôi. |
| **V3 — Expansion & Optional** | **Cold Forest**, **Crystal Depths** | Kiểm chứng chu kỳ nhiệt độ đóng/tan băng vĩnh cửu và vùng tinh thể sâu. |

---

## 5. DEPENDENCIES, RISKS & ACCEPTANCE CRITERIA

### 5.1 Dependencies (Phụ thuộc hệ thống)
- **TASK-021 World Integration Scene:** Không làm hỏng hoặc xóa bỏ mã nguồn hiện hữu của Oak Root, Dig/Fill Controller, Aquatic Manager, Weather System.
- **Coordinate Space Unity:** Mọi hệ thống con (Fauna AI, Moisture Diffusion, Camera Zoom) phải ánh xạ chuẩn xác tọa độ $X/Y$.

### 5.2 Rủi ro kỹ thuật & Giải pháp kiểm soát
1. *Rủi ro gián đoạn hiệu năng khi sinh địa hình:* Xử lý bằng thuật toán chia nhỏ thời gian (Time-sliced / Worker Generation) cho Chunk generation.
2. *Rủi ro bất đồng bộ biên giới Chunk (Edge Cracking):* Giải quyết bằng cách sử dụng các hàm toán học liên tục (Continuous Simplex Noise with Global World Coordinates) không phụ thuộc biên giới Chunk.
3. *Rủi ro phình to dữ liệu lưu trữ (Save bloat):* Chỉ lưu vết các ô bị người chơi tương tác (Delta Layer), không lưu toàn bộ mảng ô gốc đã được tạo xác định (Deterministic Base).

### 5.3 Acceptance Criteria (Tiêu chí nghiệm thu cấp thiết kế)
- [x] Bản thiết kế phân định rạch ròi 6 Surface Biomes, 2 Subterranean Biomes và hệ thống tầng địa chất tự nhiên.
- [x] Crystal Depths được đánh dấu rõ là Fantasy/Optional, loại bỏ hoàn toàn cơ chế bức xạ cưỡng bức.
- [x] Lộ trình phân bổ khả thi: Prototype V1 chỉ tập trung 4 Biomes chủ lực trên 2×3 Chunks.
- [x] Thiết kế hoàn toàn data-driven, tương thích TypeScript/PixiJS 2D.
