# BIOME DEFINITION MATRIX V1
**Project:** THE VIVARIUM  
**Branch:** `task/021-world-integration`  
**Classification:** Architecture Specification / Non-Runtime Document  
**Status:** DESIGN APPROVED (Game Director Review Aligned) / IMPLEMENTATION HOLD  
**Author:** Antigravity (World Architecture Division — Branch 04)  
**Date:** 2026-11-11  

---

## 1. SCOPE & OVERVIEW

Tài liệu này xác lập chi tiết ma trận tham số sinh thái, địa chất, mối nguy và tài nguyên cho toàn bộ 8 Biome của *THE VIVARIUM*. Đồng thời, tài liệu cung cấp đặc tả giao diện dữ liệu trừu tượng (**TypeScript Data Contracts**) làm chuẩn mực để triển khai cấu trúc dữ liệu JSON/TypeScript về sau mà không làm phát sinh runtime code trong giai đoạn này.

---

## 2. DATA CONTRACTS SPECIFICATION (DESIGN-ONLY TYPESCRIPT INTERFACES)

> **LƯU Ý:** Các định nghĩa dưới đây thuần túy phục vụ đặc tả thiết kế, **không** biên dịch thành file `.ts` trong thư mục thực thi `src/`.

```typescript
/** Phân loại Biome */
export type BiomeCategory = 'SURFACE' | 'SUBTERRANEAN';

/** Mã định danh chuẩn của 8 Biome */
export type BiomeId =
  | 'ancient_forest'
  | 'breeze_meadow'
  | 'wetland_marsh'
  | 'coastal_dunes'
  | 'arid_canyon'
  | 'cold_forest'
  | 'limestone_caverns'
  | 'crystal_depths';

/** Tham số khí hậu đặc thù */
export interface ClimateProfile {
  readonly baseTemperatureCelsius: number; // Nhiệt độ nền (°C)
  readonly temperatureDiurnalRange: number; // Biên độ dao động ngày/đêm
  readonly humidityPercent: number;        // Độ ẩm không khí (0 - 100%)
  readonly precipitationFrequency: number; // Tần suất mưa (0.0 - 1.0)
  readonly surfaceWindIntensity: number;   // Cường độ gió bề mặt (0.0 - 1.0)
}

/** Tham số địa chất và cơ học đất */
export interface GeologyProfile {
  readonly topsoilType: string;            // Loại đất bề mặt (humus, sand, clay, loess, gravel)
  readonly soilCohesionFactor: number;     // Độ gắn kết (0.0: dễ sạt lở cát, 1.0: vững chắc)
  readonly diggingDifficulty: number;      // Độ cản đào xới (1: nhanh, 5: rất cứng)
  readonly hydraulicConductivity: number;  // Độ thấm nước (tốc độ thấm ngầm mm/h)
  readonly subterraneanVoidTendency: number; // Tỉ lệ xuất hiện hốc/hang tự nhiên (0.0 - 1.0)
}

/** Sinh vật và thảm thực vật */
export interface EcologyProfile {
  readonly dominantVegetation: string[];   // Các loài thực vật chính
  readonly rareFlora: string[];            // Loài hiếm/đặc hữu
  readonly indigenousFauna: string[];      // Sinh vật bản địa (kiến, bọ, giun, v.v.)
  readonly decompositionRate: number;      // Tốc độ phân giải xác hữu cơ thành mùn
}

/** Mối nguy tự nhiên và tài nguyên */
export interface EnvironmentalHazardProfile {
  readonly primaryHazards: string[];       // Lũ quét, sạt lở, đóng băng, cát lún
  readonly hazardTriggerThreshold: number; // Ngưỡng kích hoạt
}

export interface ResourceProfile {
  readonly harvestableResources: string[]; // Gỗ mục, bùn sét, hạt giống, mật ong, v.v.
  readonly soilNutrientYield: number;      // Giá trị dinh dưỡng cung cấp cho nấm/thực vật
}

/** Data Contract đầy đủ của một Biome */
export interface BiomeDefinition {
  readonly biomeId: BiomeId;
  readonly category: BiomeCategory;
  readonly isOptionalFantasy: boolean;
  readonly climate: ClimateProfile;
  readonly geology: GeologyProfile;
  readonly ecology: EcologyProfile;
  readonly hazards: EnvironmentalHazardProfile;
  readonly resources: ResourceProfile;
  readonly depthRules: {
    readonly minDepthY: number;            // Độ sâu tối thiểu áp dụng (world coordinates)
    readonly maxDepthY: number;            // Độ sâu tối đa
    readonly bedrockTransitionY: number;   // Ngưỡng chuyển tiếp sang tầng đá nền
  };
}
```

---

## 3. CHI TIẾT MA TRẬN 8 BIOMES

### 3.1 Nhóm Sinh Cảnh Bề Mặt (Surface Biomes)

#### 01. Ancient Forest (Rừng cổ thụ)
- **Category:** `SURFACE` | **Fantasy Flag:** `false`
- **Khí hậu:** Nhiệt độ nền $18^\circ\text{C}$ (dao động ngày/đêm hẹp $\pm 4^\circ\text{C}$ do tán cây cản nhiệt); độ ẩm $85\%$; gió bề mặt yếu $0.2$; lượng mưa dồi dào.
- **Địa chất:** Đất mùn hữu cơ dày, giàu mùn đen. Hệ thống rễ cây đại thụ phân nhánh dày đặc cản trở đào thẳng hàng nhưng tạo mạng lưới chống đỡ hầm tự nhiên.
- **Sinh thái:** Tán sồi cổ thụ, dương xỉ ưa râm, nấm hoại sinh phân giải gỗ rụng. Nấm phát quang là sinh vật hiếm chỉ mọc tại rễ già thiếu sáng. Kiến thợ, ong mật, sâu đục gỗ.
- **Mối nguy:** Gỗ mục sụp đổ bất ngờ khi khoét rỗng quá mức; bóng râm cản ánh sáng phát triển của cây con tầng dưới.
- **Tài nguyên:** Mùn hữu cơ giàu dưỡng chất, phôi nấm ăn, gỗ mục, mật ong đại ngàn.

#### 02. Breeze Meadow (Đồng cỏ gió)
- **Category:** `SURFACE` | **Fantasy Flag:** `false`
- **Khí hậu:** Nhiệt độ nền $22^\circ\text{C}$ (dao động $\pm 6^\circ\text{C}$); độ ẩm $60\%$; gió liên tục $0.7$; mưa theo mùa đều đặn.
- **Địa chất:** Đất thịt mềm (Loam), rễ cỏ sợi mảnh bám nông ($0 - 5$ cells). Độ gắn kết đất trung bình ($0.65$), đào xới rất nhanh và an toàn.
- **Sinh thái:** Cỏ lau, hoa cúc vàng dại (Golden Daisy), cỏ ba lá trắng (White Clover), bướm phấn, dế mèn, giun đất.
- **Mối nguy:** Gió lốc cuốn bay hạt giống và các công trình đất đắp lộ thiên chưa nén kỹ; cháy cỏ khô vào cuối mùa ấm.
- **Tài nguyên:** Hạt giống cỏ hoa, mật hoa tươi, sợi cỏ dệt tổ, côn trùng nhỏ giàu protein.

#### 03. Wetland & Marsh (Đầm lầy & Vùng ngập nước)
- **Category:** `SURFACE` | **Fantasy Flag:** `false`
- **Khí hậu:** Nhiệt độ $25^\circ\text{C}$ (dao động $\pm 3^\circ\text{C}$); độ ẩm cực cao $95\%$; mưa rào dày đặc; gió nhẹ đến đọng khí.
- **Địa chất:** Đất bùn sét nhão (Silt & Clay), bão hòa nước ngầm. Độ gắn kết đất thấp khi ướt ($0.3$), hố đào dễ bị sụt mép và ngập nước ngay lập tức nếu không thoát nước.
- **Sinh thái:** Bèo tây, lau sậy thân rỗng, rêu than bùn (Sphagnum), ấu trùng chuồn chuồn, bọ cánh cứng bơi lội, ốc sên bùn.
- **Mối nguy:** Lũ úng tức thì sau mưa to; ngạt nước trong hầm đào trũng; bùn nhão gây kẹt di chuyển.
- **Tài nguyên:** Khối bùn sét nén (nguyên liệu gia cố thành tổ vững chắc), than bùn giữ ẩm, nước ngọt thô.

#### 04. Coastal Dunes (Cồn cát ven biển)
- **Category:** `SURFACE` | **Fantasy Flag:** `false`
- **Khí hậu:** Nhiệt độ nền $28^\circ\text{C}$ (dao động $\pm 10^\circ\text{C}$); độ ẩm $50\%$; gió biển mạnh $0.85$; bốc hơi cao.
- **Địa chất:** Cát mịn không kết dính (Cohesion $0.1$). Đào hầm bắt buộc phải có trụ chống đỡ hoặc đắp bùn sét gia cố; nếu không cát sẽ sạt lở lấp đầy hố ngay lập tức.
- **Thủy văn đặc thù (Hydrology):** Có **thấu kính nước ngọt (Freshwater Lens)** mỏng nổi bên trên tầng nước mặn ven biển. Nếu khai thác cạn kiệt hoặc đào quá sâu, nước mặn xâm nhập phá hủy sinh thái rễ cây.
- **Sinh thái:** Cỏ chịu mặn (Marram grass), xương rồng biển, bọ hung cát, bọ cạp nhỏ ăn đêm.
- **Mối nguy:** Cát lún, bão cát di chuyển làm đổi hình thái đụn, xâm nhập mặn (Saline Intrusion).
- **Tài nguyên:** Cát thạch anh lọc nước, muối khoáng tự nhiên, hạt chịu hạn.

#### 05. Arid Canyon (Hẻm núi khô cằn)
- **Category:** `SURFACE` | **Fantasy Flag:** `false`
- **Khí hậu:** Nhiệt độ nền $32^\circ\text{C}$ (dao động ngày/đêm cực đại $\pm 18^\circ\text{C}$: trưa nắng cháy rát, đêm lạnh thấu); độ ẩm thấp $25\%$; gió lốc hẹp trong khe vực.
- **Địa chất:** Đá phiến nhiều tầng nứt nẻ, xen kẽ các thấu kính đất xốp phong hóa.
- **Cơ học khai thác của kiến:** Kiến **không** sử dụng búa đục kim loại như con người; kiến bám vào các khe nứt tự nhiên, gắp từng mảnh đất xốp và vụn đá vụn đã phong hóa để mở rộng hang hốc.
- **Sinh thái:** Bụi gai khô rụng lá, thằn lằn sa mạc, nhện đất làm bẫy, bọ cánh cứng trữ nước sương.
- **Mối nguy:** Sốc nhiệt cực hạn; đá lăn từ vách cao khi có rung chấn hoặc gió giật; lũ bùn quét hiếm hoi nhưng tàn khốc khi có mưa bất chợt.
- **Tài nguyên:** Khoáng oxit kết tủa, đá phiến phẳng làm ngói chắn, tinh thể lưu huỳnh tự nhiên.

#### 06. Cold Forest (Rừng tuyết lạnh)
- **Category:** `SURFACE` | **Fantasy Flag:** `false`
- **Khí hậu:** Nhiệt độ nền $-6^\circ\text{C}$ (dao động $-15^\circ\text{C}$ đến $+2^\circ\text{C}$); độ ẩm $70\%$; bão tuyết định kỳ.
- **Địa chất hai tầng (Permafrost vs Seasonal Frost):**
  - *Tầng 1 (Đất đóng băng theo mùa - Active Layer):* Đóng băng cứng vào mùa đông, rã đông vào mùa hè. Khi rã đông, đất nhão gây sụt lún cơ học nghiêm trọng.
  - *Tầng 2 (Băng vĩnh cửu - Continuous Permafrost):* Nằm ở độ sâu lớn hơn, đá và đất bị xi măng hóa bởi băng vĩnh cửu, độ cứng cực cao, chống đào tuyệt đối nếu không có nhiệt lượng làm mềm.
- **Sinh thái:** Thông lá kim cổ thụ, địa y chịu rét, rêu băng tuyết, bọ tuyết ngủ đông.
- **Mối nguy:** Đóng băng nguồn nước lỏng; hạ thân nhiệt sinh vật; đất lún do rã đông tầng hoạt tính (Thermokarst collapse).
- **Tài nguyên:** Băng tinh khiết (tan thành nước ngọt sạch), gỗ thông dẻo chống mối mọt, nhựa thông cách nhiệt.

---

### 3.2 Nhóm Sinh Thái Lòng Đất (Subterranean Biomes)

#### 07. Limestone Caverns (Hang karst đá vôi)
- **Category:** `SUBTERRANEAN` | **Fantasy Flag:** `false`
- **Khí hậu & Vi khí hậu ngầm:** Nhiệt độ ổn định quanh năm $16^\circ\text{C}$ (hầu như không bị ảnh hưởng bởi chu kỳ ngày đêm); độ ẩm $100\%$; không có gió tự nhiên ngoài các luồng khí đối lưu do chênh lệch áp suất hang.
- **Địa chất & Thủy văn Karst (Karst Aquifer):** Vòm đá vôi bị nước mưa hòa tan tạo thành hệ thống khoang rỗng thông nhau tự nhiên, kèm nhũ đá (Stalactite/Stalagmite).
  - *Đặc tính dòng chảy:* Nước không thấm rỉ chậm qua đất mà chảy nhanh thành dòng suối ngầm áp lực qua các khe nứt lớn và ống dẫn karst rỗng.
- **Sinh thái:** Nấm hang không cần quang hợp, bọ hang mù mất sắc tố, dơi làm tổ trên trần vòm cao.
- **Mối nguy:** Nhũ đá rơi gãy; ngập lụt tức thời khi mưa lớn trên bề mặt đổ dồn vào các hố sụt (Sinkholes); túi khí tù đọng thiếu oxy.
- **Tài nguyên:** Bột đá vôi khử chua, nước ngầm siêu sạch lọc qua đá, phân dơi giàu nitrat (Guano) làm phân bón hữu cơ cao cấp.

#### 08. Crystal Depths (Vực tinh thể sâu)
- **Category:** `SUBTERRANEAN` | **Fantasy Flag:** `true` *(NỘI DUNG GIẢ TƯỞNG / TÙY CHỌN)*
- **Nguyên tắc thiết kế:** Không đưa bức xạ hạt nhân, ô nhiễm phóng xạ hay mana phép thuật vào các quy luật sinh thái mặc định của The Vivarium.
- **Khí hậu:** Nhiệt độ ấm $28 - 35^\circ\text{C}$ do tiếp giáp nhiệt lượng lòng đất; độ ẩm trung bình; áp suất nén cao.
- **Địa chất:** Vòm tinh thể rỗng khổng lồ (Geode) phát triển trên nền đá bazan cứng. Tinh thể silicat, thạch anh và fluorite phản chiếu ánh sáng tự nhiên từ dung nham nguội hoặc vi khoáng phát quang.
- **Sinh thái:** Nấm tinh thể dạng sợi vô cơ, vi khuẩn ưa nhiệt, sinh vật vỏ giáp khoáng cứng.
- **Mối nguy:** Mảnh tinh thể vỡ sắc bén; hơi khí lưu huỳnh nóng từ mạch nứt magma; hang sâu khó tiếp cận oxy.
- **Tài nguyên:** Tinh thể quang học, khối thạch anh trữ nhiệt, khoáng chất kết tinh quý hiếm.

---

## 4. ACCEPTANCE CRITERIA
- [x] Mỗi Biome có đầy đủ 6 thông số: Khí hậu, Địa chất, Sinh thái, Mối nguy, Tài nguyên, Hệ ngầm.
- [x] Phân định chuẩn xác hiện thực khoa học cho Cold Forest (băng vĩnh cửu vs rã đông) và Coastal Dunes (thấu kính nước ngọt).
- [x] Kiến chỉ khai thác hẻm núi Arid Canyon theo cơ học tự nhiên phù hợp loài kiến.
- [x] Định dạng dữ liệu hoàn toàn tương thích với mô hình Data-Driven của TypeScript/PixiJS.
